import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';

// ✅ API key lives here (server-side), NEVER reaches the browser
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { imageData, mimeType, prompt } = req.body;

  if (!imageData || !prompt) {
    return res.status(400).json({ error: 'imageData and prompt are required' });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash-preview-image-generation',
      contents: {
        parts: [
          { inlineData: { data: imageData, mimeType: mimeType || 'image/jpeg' } },
          { text: prompt },
        ],
      },
      // ✅ Required to get image output (was missing in original)
      generationConfig: {
        responseModalities: ['IMAGE', 'TEXT'],
      } as never,
    });

    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
      for (const part of parts) {
        if (part.inlineData?.data && part.inlineData?.mimeType) {
          return res.status(200).json({
            data: part.inlineData.data,
            mimeType: part.inlineData.mimeType,
          });
        }
      }
    }

    return res.status(422).json({ error: 'No se generó imagen. Intentá con otro prompt.' });
  } catch (error: unknown) {
    console.error('Gemini API error:', error);
    const msg = error instanceof Error ? error.message : 'Error desconocido';
    return res.status(500).json({ error: `Error de IA: ${msg}` });
  }
}
