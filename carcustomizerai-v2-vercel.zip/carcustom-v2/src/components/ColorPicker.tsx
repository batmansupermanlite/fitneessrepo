
import React, { useState } from 'react';
import type { Modification } from '../types';
import { ModificationType } from '../types';

interface ColorPickerProps {
    onApply: (modification: Modification) => void;
    disabled: boolean;
    modificationType?: ModificationType;
    promptPrefix?: string;
}

const colors = [
    { name: 'Negro', hex: '#1a1a1a', prompt: 'black' },
    { name: 'Blanco', hex: '#f0f0f0', prompt: 'white' },
    { name: 'Gris Nardo', hex: '#8a9297', prompt: 'nardo gray' },
    { name: 'Plata', hex: '#c0c0c0', prompt: 'silver' },
    { name: 'Rojo Cereza', hex: '#c20000', prompt: 'cherry red' },
    { name: 'Azul Medianoche', hex: '#001f5c', prompt: 'midnight blue' },
    { name: 'Verde Carreras', hex: '#004225', prompt: 'british racing green' },
    { name: 'Amarillo Eléctrico', hex: '#ffff00', prompt: 'electric yellow' },
    { name: 'Púrpura', hex: '#3c1361', prompt: 'purple' },
    { name: 'Fibra de Carbono', hex: '#2a2a2a', prompt: 'exposed carbon fiber weave', isTexture: true },
];

const finishes = [
    { id: 'gloss', label: 'Brillo', prompt: 'high gloss' },
    { id: 'matte', label: 'Mate', prompt: 'matte' },
    { id: 'metallic', label: 'Metálico', prompt: 'metallic' },
    { id: 'satin', label: 'Satinado', prompt: 'satin semi-gloss' },
];

const parts = [
    { id: 'full', label: 'Carrocería Completa' },
    { id: 'hood', label: 'Capó' },
    { id: 'roof', label: 'Techo' },
    { id: 'mirrors', label: 'Espejos' },
    { id: 'spoiler', label: 'Alerón' },
    { id: 'front_bumper', label: 'Parachoques Delantero' },
    { id: 'rear_bumper', label: 'Parachoques Trasero' },
    { id: 'trunk', label: 'Maletero' },
    { id: 'calipers', label: 'Pinzas de Freno' },
];

const ColorPicker: React.FC<ColorPickerProps> = ({ 
    onApply, 
    disabled, 
    modificationType = ModificationType.COLOR, 
    promptPrefix = "change the car's paint color to" 
}) => {
    const [selectedColor, setSelectedColor] = useState(colors[0]);
    const [selectedFinish, setSelectedFinish] = useState(finishes[0]);
    const [customColorHex, setCustomColorHex] = useState('#1a1a1a');
    const [customColorName, setCustomColorName] = useState('');
    const [mode, setMode] = useState<'preset' | 'custom'>('preset');
    const [selectedPart, setSelectedPart] = useState(parts[0]);

    const handlePresetClick = (color: typeof colors[0]) => {
        setSelectedColor(color);
        setMode('preset');
    };

    const handleCustomHexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCustomColorHex(e.target.value);
        setMode('custom');
    };

    const handleCustomNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCustomColorName(e.target.value);
        setMode('custom');
    };

    const handleApply = () => {
        const colorPrompt = mode === 'preset' ? selectedColor.prompt : (customColorName.trim() ? customColorName : customColorHex);
        const colorDisplay = mode === 'preset' ? selectedColor.name : (customColorName || customColorHex);
        
        // Don't use finish if the color is Carbon Fiber (it has its own texture)
        const isCarbon = mode === 'preset' && selectedColor.isTexture;
        const finishPrompt = isCarbon ? '' : selectedFinish.prompt;
        const finishDisplay = isCarbon ? '' : selectedFinish.label;

        let finalPrompt = '';

        if (modificationType === ModificationType.COLOR) {
            const materialDescription = isCarbon ? colorPrompt : `${finishPrompt} ${colorPrompt} paint`;
            
            if (selectedPart.id === 'full') {
                finalPrompt = `Change the car's entire body to ${materialDescription}. Apply this to all painted body panels including bumpers, side skirts, fenders, hood, roof, and doors. Ensure high precision. Do not change windows, lights, grille, or tires.`;
            } else {
                finalPrompt = `Change only the ${selectedPart.label.toLowerCase()} to ${materialDescription}. Keep the rest of the car's body paint exactly as it is. Ensure high precision at the edges of the ${selectedPart.label.toLowerCase()}.`;
            }
        } else if (modificationType === ModificationType.WHEELS) {
            const materialDescription = isCarbon ? colorPrompt : `${finishPrompt} ${colorPrompt}`;
            finalPrompt = `Change the color of the car's wheels (rims) to ${materialDescription}. Ensure the tires remain black rubber.`;
        } else {
            finalPrompt = `${promptPrefix} ${finishPrompt} ${colorPrompt}`;
        }

        const displayValue = `${selectedPart.id !== 'full' && modificationType === ModificationType.COLOR ? selectedPart.label + ' ' : ''}${finishDisplay} ${colorDisplay}`.trim();

        onApply({
            type: modificationType,
            value: displayValue,
            prompt: finalPrompt,
        });
    };

    return (
        <div className="space-y-6">
            {/* Part Selector - Only show for Body Paint */}
            {modificationType === ModificationType.COLOR && (
                <div className="space-y-3">
                    <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Área Objetivo</h3>
                    <div className="flex flex-wrap gap-2">
                        {parts.map((part) => (
                            <button
                                key={part.id}
                                onClick={() => setSelectedPart(part)}
                                disabled={disabled}
                                className={`px-3 py-1.5 text-xs font-bold rounded-full transition-all duration-200 border ${
                                    selectedPart.id === part.id
                                    ? 'bg-blue-600 border-blue-500 text-white shadow-md'
                                    : 'bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700 hover:text-white'
                                }`}
                            >
                                {part.label}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Finish Selector - Hide if Carbon Fiber is selected */}
            {(!selectedColor.isTexture || mode === 'custom') && (
                <div className="space-y-3">
                    <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Acabado</h3>
                    <div className="grid grid-cols-4 gap-2">
                        {finishes.map((finish) => (
                            <button
                                key={finish.id}
                                onClick={() => setSelectedFinish(finish)}
                                disabled={disabled}
                                className={`py-2 text-sm font-medium rounded-lg transition-all duration-200 border ${
                                    selectedFinish.id === finish.id
                                    ? 'bg-gray-600 border-gray-500 text-white ring-1 ring-gray-400'
                                    : 'bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700'
                                }`}
                            >
                                {finish.label}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Color / Material</h3>
                <div className="grid grid-cols-5 gap-3">
                    {colors.map((color) => (
                        <button
                            key={color.name}
                            onClick={() => handlePresetClick(color)}
                            className={`relative w-full aspect-square rounded-full border-2 transition-transform duration-150 transform hover:scale-110 flex items-center justify-center overflow-hidden ${
                                mode === 'preset' && selectedColor.name === color.name ? 'border-white scale-110 shadow-lg ring-2 ring-blue-500/50' : 'border-transparent ring-1 ring-white/10'
                            }`}
                            style={{ 
                                background: color.isTexture 
                                    ? `repeating-linear-gradient(45deg, #222 0px, #222 2px, #444 2px, #444 4px)` 
                                    : color.hex
                            }}
                            title={color.name}
                            disabled={disabled}
                        >
                            {/* Checkmark for active */}
                            {mode === 'preset' && selectedColor.name === color.name && (
                                <div className="bg-black/20 rounded-full p-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-white">
                                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                    </svg>
                                </div>
                            )}
                        </button>
                    ))}
                </div>
            </div>

            <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Hex Personalizado</h3>
                <div 
                    className={`p-3 rounded-xl border transition-all duration-200 ${
                        mode === 'custom' 
                        ? 'border-blue-500 bg-gray-700/50' 
                        : 'border-gray-700 bg-gray-800 hover:border-gray-600'
                    }`}
                    onClick={() => setMode('custom')}
                >
                    <div className="flex items-center gap-4">
                        <div className="flex-shrink-0">
                            <input
                                type="color"
                                value={customColorHex}
                                onChange={handleCustomHexChange}
                                disabled={disabled}
                                className="h-10 w-10 p-0 rounded-full cursor-pointer bg-transparent border-0 overflow-hidden"
                            />
                        </div>
                        <div className="flex-grow">
                            <input
                                type="text"
                                value={customColorName}
                                onChange={handleCustomNameChange}
                                onFocus={() => setMode('custom')}
                                placeholder="ej. Cambio de Color, Óxido..."
                                disabled={disabled}
                                className="w-full bg-transparent border-none focus:ring-0 text-white text-sm placeholder-gray-500"
                            />
                        </div>
                    </div>
                </div>
            </div>

            <div className="pt-2">
                <button
                    onClick={handleApply}
                    disabled={disabled}
                    className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white font-bold py-3 px-4 rounded-lg disabled:from-gray-700 disabled:to-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transition-all shadow-lg shadow-blue-900/20"
                >
                    Aplicar Pintura
                </button>
            </div>
        </div>
    );
};

export default ColorPicker;
