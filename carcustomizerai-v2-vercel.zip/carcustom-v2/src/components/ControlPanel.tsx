
import React, { useState } from 'react';
import type { Modification, WheelOption, BodykitOption, BackgroundOption, ModificationOption } from '../types';
import { ModificationType } from '../types';
import ColorPicker from './ColorPicker';
import OptionSelector from './OptionSelector';
import { ResetIcon } from './icons';

const wheelOptions: WheelOption[] = [
    { 
        label: 'Negro 5-Radios', 
        value: 'w1', 
        prompt: 'change the wheels to black 5-spoke racing rims',
        description: 'Un aspecto clásico y minimalista de carreras. Proporciona una estética sigilosa y orientada al rendimiento.'
    },
    { 
        label: 'Cromo Plato Profundo', 
        value: 'w2', 
        prompt: 'change the wheels to chrome deep dish rims',
        description: 'Acabado de espejo de alto pulido con un borde ancho. Perfecto para estilos VIP y de exhibición.'
    },
    { 
        label: 'Bronce Estilo TE37', 
        value: 'w3', 
        prompt: 'change the wheels to bronze TE37 style rims',
        description: 'Estilo icónico JDM. El acabado en bronce añade un contraste premium a casi cualquier color de carrocería.'
    },
    { 
        label: 'Blanco Estilo Rally', 
        value: 'w4', 
        prompt: 'change the wheels to white rally style multispoke rims',
        description: 'Radios blancos de alta visibilidad diseñados para un aspecto robusto e inspirado en el automovilismo.'
    },
];

const bodykitOptions: BodykitOption[] = [
    { 
        label: 'Estilo Calle', 
        value: 'b1', 
        prompt: 'add a sporty street style bodykit with a front lip spoiler and side skirts',
        description: 'Adiciones limpias y sutiles que realzan las líneas naturales del coche sin ser demasiado agresivas.'
    },
    { 
        label: 'Kit de Carrocería Ancha', 
        value: 'b2', 
        prompt: 'add an aggressive widebody kit with fender flares',
        description: 'Amplía masivamente el perfil del coche con extensiones de guardabarros atornilladas o moldeadas para una presencia muscular.'
    },
    { 
        label: 'Estilo Drift', 
        value: 'b3', 
        prompt: 'add a drift style bodykit with a large rear wing and aggressive front bumper',
        description: 'Aerodinámica y refrigeración maximizadas. Incluye un alerón alto estilo GT para estabilidad a alta velocidad.'
    },
    { 
        label: 'Kit de Fibra de Carbono', 
        value: 'b4', 
        prompt: 'add a carbon fiber bodykit, including a front splitter and rear diffuser',
        description: 'Materiales compuestos de alta tecnología. Añade detalles de tejido de carbono expuesto a splitters, faldones y difusores.'
    },
];

const vinylOptions: ModificationOption<string>[] = [
    { 
        label: 'Franjas de Carreras Laterales', 
        value: 'v1', 
        prompt: 'add aggressive dual racing stripes in a contrasting color along the side of the car, following the body lines',
        description: 'Alarga visualmente el coche y enfatiza la línea de cintura para un aspecto clásico de muscle car o GT.'
    },
    { 
        label: 'Kanji Japonés "Rey del Drift"', 
        value: 'v3', 
        prompt: 'add Japanese kanji for "Drift King" (ドリフトキング) on the rear quarter panel in a stylized, bold font',
        description: 'Auténtica estética de la cultura del drift. Añade un elemento gráfico audaz a la parte trasera del vehículo.'
    },
    { 
        label: 'Envoltura de Camuflaje', 
        value: 'v4', 
        prompt: 'apply a geometric urban camouflage vinyl wrap pattern to the entire car body',
        description: 'Una envoltura de cuerpo completo con un patrón de camuflaje geométrico táctico.'
    },
];

const tintOptions: ModificationOption<string>[] = [
    { 
        label: 'Negro Limusina (5%)', 
        value: 't1', 
        prompt: 'darken the car windows with a 5% limo tint, making them almost completely black and opaque',
        description: 'Máxima privacidad y rechazo del calor. Casi imposible ver hacia adentro.'
    },
    { 
        label: 'Humo (35%)', 
        value: 't2', 
        prompt: 'apply a medium 35% smoke tint to the car windows',
        description: 'Un aspecto equilibrado, más de fábrica. Añade estilo sin comprometer la visibilidad nocturna.'
    },
    { 
        label: 'Espejo Azul', 
        value: 't3', 
        prompt: 'apply a reflective blue mirror tint to the car windows',
        description: 'Superficie altamente reflectante con un tono azul frío. Distintivo y moderno.'
    },
    { 
        label: 'Camaleón / Neo', 
        value: 't4', 
        prompt: 'apply a color-shifting chameleon tint to the windshield and windows that shifts between purple and green',
        description: 'Tinte dinámico que cambia de color dependiendo del ángulo de la luz.'
    },
];

const backgroundOptions: BackgroundOption[] = [
    {
        label: 'Garaje de Lujo',
        value: 'bg1',
        prompt: 'change the background to a clean, well-lit luxury modern garage showroom with concrete floors',
        description: 'Un entorno de estudio profesional de alta gama para mostrar el vehículo.'
    },
    {
        label: 'Ciudad Cyberpunk',
        value: 'bg2',
        prompt: 'change the background to a futuristic neon-lit cyberpunk city street at night with rain reflections',
        description: 'Iluminación de neón oscura, cambiante y colorida para un aspecto cinematográfico.'
    },
    {
        label: 'Pista de Carreras',
        value: 'bg3',
        prompt: 'change the background to a professional race track circuit during the day with curbing visible',
        description: 'Pon el coche en su hábitat natural en el asfalto.'
    },
    {
        label: 'Carretera Costera Escénica',
        value: 'bg4',
        prompt: 'change the background to a scenic coastal highway with the ocean in the distance and sunset lighting',
        description: 'Iluminación cálida y hermosos paisajes para una estética de estilo de vida.'
    },
];

interface ControlPanelProps {
    onApply: (modification: Modification) => void;
    onReset: () => void;
    isLoading: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ onApply, onReset, isLoading }) => {
    const [activeTab, setActiveTab] = useState<ModificationType>(ModificationType.COLOR);
    const [vinylPrompt, setVinylPrompt] = useState<string>('');
    const [wheelMode, setWheelMode] = useState<'style' | 'color'>('style');

    const renderPanel = () => {
        switch(activeTab) {
            case ModificationType.COLOR:
                return <ColorPicker onApply={onApply} disabled={isLoading} />;
            case ModificationType.WHEELS:
                return (
                    <div className="space-y-6">
                        <div className="flex space-x-2 bg-gray-700 p-1 rounded-lg">
                            <button 
                                onClick={() => setWheelMode('style')}
                                className={`flex-1 py-2 text-sm font-semibold rounded-md transition-all ${
                                    wheelMode === 'style' 
                                    ? 'bg-gray-600 text-white shadow ring-1 ring-white/10' 
                                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/50'
                                }`}
                            >
                                Estilo de Llanta
                            </button>
                            <button 
                                onClick={() => setWheelMode('color')}
                                className={`flex-1 py-2 text-sm font-semibold rounded-md transition-all ${
                                    wheelMode === 'color' 
                                    ? 'bg-gray-600 text-white shadow ring-1 ring-white/10' 
                                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/50'
                                }`}
                            >
                                Pintura de Llanta
                            </button>
                        </div>
                        
                        {wheelMode === 'style' ? (
                             <OptionSelector 
                                title="Selección de Llantas" 
                                options={wheelOptions} 
                                onApply={(opt) => onApply({type: ModificationType.WHEELS, value: opt.value, prompt: opt.prompt})} 
                                disabled={isLoading} 
                            />
                        ) : (
                            <ColorPicker 
                                onApply={onApply} 
                                disabled={isLoading} 
                                modificationType={ModificationType.WHEELS}
                                promptPrefix="change the wheels color to"
                            />
                        )}
                    </div>
                );
            case ModificationType.TINT:
                 return <OptionSelector title="Tintes de Ventana" options={tintOptions} onApply={(opt) => onApply({type: ModificationType.TINT, value: opt.value, prompt: opt.prompt})} disabled={isLoading} />;
            case ModificationType.BODYKIT:
                return <OptionSelector title="Aero y Carrocería" options={bodykitOptions} onApply={(opt) => onApply({type: ModificationType.BODYKIT, value: opt.value, prompt: opt.prompt})} disabled={isLoading} />;
            case ModificationType.VINYL:
                return (
                    <div className="space-y-6">
                        <div>
                           <OptionSelector 
                                title="Vinilos Populares"
                                options={vinylOptions} 
                                onApply={(opt) => onApply({type: ModificationType.VINYL, value: opt.value, prompt: opt.prompt})} 
                                disabled={isLoading} 
                            />
                        </div>

                        <div className="relative">
                           <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                <div className="w-full border-t border-gray-600" />
                            </div>
                            <div className="relative flex justify-center">
                                <span className="bg-gray-800 px-2 text-sm text-gray-400">O</span>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h3 className="text-xl font-semibold">Diseño Personalizado</h3>
                            <p className="text-sm text-gray-400">Describe exactamente qué pegatina o patrón de vinilo quieres ver.</p>
                            <textarea 
                                value={vinylPrompt}
                                onChange={(e) => setVinylPrompt(e.target.value)}
                                className="w-full h-24 p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition text-gray-100 placeholder-gray-500 text-sm"
                                placeholder="ej., un patrón geométrico dorado envolviendo el parachoques delantero..."
                                disabled={isLoading}
                            />
                            <button
                                onClick={() => onApply({type: ModificationType.VINYL, value: vinylPrompt, prompt: vinylPrompt})}
                                disabled={isLoading || !vinylPrompt.trim()}
                                className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-600 disabled:text-gray-400 disabled:cursor-not-allowed transition-all"
                            >
                                Aplicar Diseño Personalizado
                            </button>
                        </div>
                    </div>
                );
            case ModificationType.BACKGROUND:
                return <OptionSelector title="Entorno" options={backgroundOptions} onApply={(opt) => onApply({type: ModificationType.BACKGROUND, value: opt.value, prompt: opt.prompt})} disabled={isLoading} />;
        }
    };
    
    const tabs = [
        { type: ModificationType.COLOR, label: 'Pintura' },
        { type: ModificationType.WHEELS, label: 'Llantas' },
        { type: ModificationType.TINT, label: 'Tinte' },
        { type: ModificationType.BODYKIT, label: 'Aero' },
        { type: ModificationType.VINYL, label: 'Gráficos' },
        { type: ModificationType.BACKGROUND, label: 'Escena' },
    ];

    return (
        <div className="bg-gray-800 p-6 rounded-xl shadow-lg h-full flex flex-col border border-gray-700">
            <div className="flex flex-col mb-4">
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-white">Taller Virtual</h2>
                        <p className="text-xs text-gray-500 mt-1">Las modificaciones se aplican a todas las vistas</p>
                    </div>
                    <button
                        onClick={onReset}
                        disabled={isLoading}
                        className="flex items-center space-x-2 text-sm text-gray-400 hover:text-red-400 disabled:opacity-50 transition-colors bg-gray-700/50 hover:bg-gray-700 px-3 py-1.5 rounded-lg"
                        title="Restablecer todas las modificaciones"
                    >
                        <ResetIcon className="w-4 h-4"/>
                        <span>Restablecer</span>
                    </button>
                </div>
            </div>
            
            <div className="border-b border-gray-700 mb-6">
                <nav className="-mb-px flex space-x-4 overflow-x-auto pb-2 scrollbar-hide" aria-label="Tabs">
                    {tabs.map(tab => (
                        <button
                            key={tab.type}
                            onClick={() => setActiveTab(tab.type)}
                            className={`whitespace-nowrap pb-2 border-b-2 font-semibold text-sm transition-all flex-shrink-0
                                ${activeTab === tab.type 
                                    ? 'border-blue-500 text-blue-400' 
                                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-600'}`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </nav>
            </div>
            
            <div className="flex-grow overflow-y-auto pr-1 custom-scrollbar">
                {renderPanel()}
            </div>
        </div>
    );
};

export default ControlPanel;
