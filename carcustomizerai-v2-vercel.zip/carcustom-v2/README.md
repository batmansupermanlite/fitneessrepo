# 🚗 CarCustomizerAI v2

App de personalización de autos con IA. Subí una foto de tu auto y visualizá modificaciones en tiempo real.

## ✅ Mejoras v2
- **Seguridad**: La API key nunca llega al navegador (función serverless)
- **Deshacer**: Podés deshacer hasta 8 modificaciones por vista
- **Notificaciones**: Toasts en lugar de alerts del browser
- **Tiempo estimado**: Se muestra cuánto puede tardar la IA
- **Mejor manejo de errores**: Mensajes específicos por fallo

---

## 🚀 Deploy en Vercel (método más fácil)

### Paso 1 — Subir el código a GitHub

```bash
git init
git add .
git commit -m "CarCustomizerAI v2"
```

Creá un repositorio nuevo en [github.com](https://github.com/new) y luego:

```bash
git remote add origin https://github.com/TU_USUARIO/car-customizer-ai.git
git push -u origin main
```

### Paso 2 — Conectar con Vercel

1. Entrá a [vercel.com](https://vercel.com) y creá una cuenta (gratis)
2. Click en **"Add New Project"**
3. Importá tu repositorio de GitHub
4. Vercel detecta automáticamente que es un proyecto Vite

### Paso 3 — Agregar la API Key de Gemini

En Vercel, antes de hacer deploy:
1. Andá a **Settings → Environment Variables**
2. Agregá:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: Tu key de [Google AI Studio](https://aistudio.google.com/apikey)
3. Click **Save**

### Paso 4 — Deploy

Click en **Deploy** y en 2 minutos tenés tu URL pública para compartir.

---

## 💻 Correr localmente

```bash
npm install
```

Creá el archivo `.env.local`:
```
GEMINI_API_KEY=tu_api_key_aqui
```

```bash
npm run dev
```

Para probar las funciones serverless localmente:
```bash
npm install -g vercel
vercel dev
```

---

## 🔑 Conseguir API Key de Gemini

1. Entrá a [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
2. Click en **"Create API Key"**
3. Copiá la key y pegala en Vercel como variable de entorno

**⚠️ Nunca compartas tu API key ni la pongas en el código.**
