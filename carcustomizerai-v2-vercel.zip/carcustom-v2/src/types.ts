export enum ModificationType {
  COLOR = 'COLOR',
  WHEELS = 'WHEELS',
  BODYKIT = 'BODYKIT',
  VINYL = 'VINYL',
  TINT = 'TINT',
  BACKGROUND = 'BACKGROUND',
}

export interface ModificationOption<T> {
  label: string;
  value: T;
  prompt: string;
  description?: string;
}

export type WheelOption = ModificationOption<string>;
export type BodykitOption = ModificationOption<string>;
export type BackgroundOption = ModificationOption<string>;

export type Modification = {
  type: ModificationType;
  value: string;
  prompt: string;
};

export interface CarView {
  id: string;
  label: string;
  file: File;
}

// ✅ NEW: history stack per view for undo support
export interface ViewState {
  id: string;
  label: string;
  original: string;
  modified: string;
  history: string[];   // stack of previous modified states
  isLoading: boolean;
  error: string | null;
}

export const MAX_HISTORY = 8;
