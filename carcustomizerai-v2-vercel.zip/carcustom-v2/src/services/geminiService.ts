export interface ModificationResult {
  data: string;
  mimeType: string;
}

const fileToBase64 = (file: File): Promise<{ data: string; mimeType: string }> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      resolve({
        data: result.split(',')[1],
        mimeType: file.type,
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

const dataUrlToBase64 = (dataUrl: string): { data: string; mimeType: string } => {
  const [header, data] = dataUrl.split(',');
  const mimeType = header.match(/:(.*?);/)?.[1] || 'image/png';
  return { data, mimeType };
};

// ✅ Now calls our secure serverless function instead of Gemini directly
export const applyModification = async (
  imageData: File | string,
  prompt: string
): Promise<ModificationResult | null> => {
  let base64: { data: string; mimeType: string };

  if (imageData instanceof File) {
    base64 = await fileToBase64(imageData);
  } else {
    base64 = dataUrlToBase64(imageData);
  }

  const response = await fetch('/api/modify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageData: base64.data, mimeType: base64.mimeType, prompt }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Error desconocido' }));
    throw new Error(err.error || `HTTP ${response.status}`);
  }

  return response.json();
};
